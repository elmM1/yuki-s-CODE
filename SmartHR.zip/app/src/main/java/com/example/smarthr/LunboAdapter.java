package com.example.smarthr;

import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.viewpager.widget.PagerAdapter;

import java.util.List;

public class LunboAdapter extends PagerAdapter {
    private List<Integer> imgs = null;

    public LunboAdapter(List<Integer> imgs) {
        this.imgs = imgs;
    }

    @Override
    public int getCount() {
        return Integer.MAX_VALUE;//伪无线循环，设置最大值
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view == object;
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, int position) {//alt+insert插入此参数
        int realposition = position % imgs.size();  //因为只有三张图片  所以position 最大值为2， 这样是让 0 1 2 无限循环
        ImageView imageView = new ImageView(container.getContext());
        imageView.setImageResource(imgs.get(realposition)); //将重置的数添加到里面
        container.addView(imageView);
        return imageView;
    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {//alt+insert插入此参数
        container.removeView((View) object);
    }

    public void setdata(List<Integer> imgs) {
    }



}

