package com.example.smarthr.tool;

import android.os.Handler;
import android.util.Log;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.UnknownHostException;


public class TcpSocket {

    public void closeConnect() {
    }

    // 监听输入流返回信息的接口
    public interface OnReadListener{
        // 正在连接问题，由主线程回调
        public void onConneting();
        // 连接成功回调，由主线程回调，ip 返回服务器IP
        public void onConnectSuccess(String ip);
        // 连接超时问题，由主线程回调
        public void onConnectTimeOut();
        // 失去连接问题，由主线程回调
        public void onConnectLost();
        // 服务器返回数据的问题
        public void onRead(byte[] b ,int len, Socket so);
    }

    //主线程的Handler
    private Handler handler;
    // socket接套字
    private Socket so;
    // 判断是否已经建立连接
    public boolean isConnect=false;
    // 判断是否正在连接
    private boolean isConnectIng=false;
    // socket输出流对象
    private OutputStream out;
    // Socket输入流
    private InputStream in;
    // 信息返回的监听事件
    private OnReadListener listener;
    private String ip;
    private int port;
    // 构造方法
    public TcpSocket(){
        handler=new Handler();
    }
    // 设置信息返回的监听事件
    public void setListener(OnReadListener listener){
        this.listener=listener;
    }

    //回调的主线程
    private class MainThread implements Runnable{
        int what;
        public MainThread(int what){
            this.what=what;
        }
        @Override
        public void run(){
            if(listener==null){
                return;
            }
            switch (what){
                case 100:
                    listener.onConnectTimeOut();
                    break;
                case 200:
                    listener.onConnectLost();
                    break;
                case 300:
                    listener.onConnectSuccess(ip);
                    break;
                case 400:
                    listener.onConneting();
                    break;
            }
            isConnectIng=false;
        }
    }

    // 连接服务器的线程
    private class ConnectThread implements Runnable{
        public ConnectThread(String dstName,int dstPort){
            ip=dstName;
            port=dstPort;
        }
        @Override
        public void run(){
            try{
                try{
                    Thread.sleep(500);
                }catch (InterruptedException e){
                    e.printStackTrace();
                }
                Log.e("DATA","正在连接到IP:"+ip);
                if(listener!=null){
                    handler.post(new MainThread(400));
                }
                so=new Socket();
                InetSocketAddress isa=new InetSocketAddress(ip,port);
                so.connect(isa,2000);
                out=so.getOutputStream();
                in=so.getInputStream();
                isConnect=true;
                if (listener!=null){
                    handler.post(new MainThread(300));
                }
                byte[] b=new byte[6666];
                int hasRead=0;
                while((hasRead=in.read(b))>0){
                    if (listener!=null){
                        int finalHasRead=hasRead;
                        handler.post(new Runnable() {
                            @Override
                            public void run() {
                                listener.onRead(b,finalHasRead,so);
                            }
                        });
                    }
                }
            }catch (UnknownHostException e){
                handler.post(new MainThread(100));
            }catch (IOException e){
                String err=e.getMessage();
                if (err.contains("Socket closed")){
                    handler.post(new MainThread(200));
                }else if (err.contains("failed to connect")){
                    handler.post(new MainThread(100));
                }else {
                    e.printStackTrace();
                }
            }finally {
                if (so!=null){
                    if(!isConnectIng){
                        handler.post(new MainThread(200));
                    }
                    try {
                        so.close();
                        isConnect=false;
                        if(out!=null){
                            out.close();
                        }
                        if (in !=null){
                            in.close();
                        }
                        so=null;
                        out=null;
                        in=null;
                        isConnectIng=false;
                    }catch (IOException e){
                        e.printStackTrace();
                    }
                }
            }
        }
    }

    // 连接到模块
    public void conncet(final String dstName,final int dstPort){
        if(!isConnect && !isConnectIng){
            isConnectIng=true;
            new Thread(new ConnectThread(dstName,dstPort)).start();
        }
    }

    // 发送信息到服务器
    public void sendDataToServer(final byte[] data){
        new Thread(new Runnable() {
            @Override
            public void run() {
                if (out!=null){
                    try{
                        out.write(data);
                        out.flush();
                        Log.d("MSG","发送success");
                    }catch (IOException e){
                        e.printStackTrace();
                    }
                }
            }
        }).start();
    }

    // 发送信息到服务器
    public void sendDataToServer(final String data){
        new Thread(new Runnable() {
            @Override
            public void run() {
                if (out!=null){
                    try{
                        Log.d("MSG","发送："+data);
                        out.write(data.getBytes());
                        out.flush();
                    }catch (IOException e){
                        System.out.println(e.getMessage());
                        if(e.getMessage().contains("Socket closed")){
                            handler.post(new MainThread(200));
                        }
                    }
                }
            }
        }).start();
    }
}
