package com.example.smarthr;

import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import com.example.smarthr.tool.TcpSocket;

import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

import static com.example.smarthr.MainActivity.tcpsocket;

public class Ex1Activity extends AppCompatActivity {
     //网络连接工具
    private TcpSocket tcpsocket;
    // 组件
    private EditText edit_num1, edit_num2, edit_num3, edit_num4, edit_msg;
    private Button bt_send;

    //轮播
    RadioButton dot1,dot2,dot3;
    RadioGroup rg_dot;
    ViewPager lunbo;
    Handler mHandler = new Handler();
    static List<Integer> imgs  = new ArrayList<>();
    static {
        imgs.add(R.mipmap.p1);
        imgs.add(R.mipmap.p2);
        imgs.add(R.mipmap.p3);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ex1);
        //创建一个工具类
        initview();
        getSupportActionBar().hide();
        init();
    }



    private void initview() {

        new Thread(new Runnable() {
            @Override
            public void run() {
                int i = lunbo.getCurrentItem();
                lunbo.setCurrentItem(++i,true);
                mHandler.postDelayed(this,2000);
            }
        }).start();

        dot1= findViewById(R.id.dot_1);
        dot2= findViewById(R.id.dot_2);
        dot3= findViewById(R.id.dot_3);
        lunbo = findViewById(R.id.lunbo);
        rg_dot = findViewById(R.id.rg_dot);

        LunboAdapter lunboAdapter = new LunboAdapter(imgs);//创建适配器对象
        lunbo.setAdapter(lunboAdapter);//创建适配器
        setdot(true,false,false);

        rg_dot.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                switch (i) {
                    case R.id.dot_1:
                        lunbo.setCurrentItem(0);
                        break;
                    case R.id.dot_2:
                        lunbo.setCurrentItem(1);
                        break;
                    case R.id.dot_3:
                        lunbo.setCurrentItem(2);
                        break;

                }
            }
        });
        lunboAdapter.setdata(imgs);
        lunbo.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
            }
            @Override
            public void onPageSelected(int position) {
                int realposition = position % imgs.size();
                switch (realposition) {
                    case 0 :
                        setdot(true,false,false);

                        break;
                    case 1 :
                        setdot(false,true,false);

                        break;
                    case 2 :
                        setdot(false,false,true);
                        break;
                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {
            }
        });
    }

    private void setdot(boolean a, boolean b, boolean c) {
        if (a) {
            dot1.setBackgroundResource(R.drawable.dot_select);
        } else {
            dot1.setBackgroundResource(R.drawable.dot_notselect);
        }
        if (b) {
            dot2.setBackgroundResource(R.drawable.dot_select);
        } else {
            dot2.setBackgroundResource(R.drawable.dot_notselect);
        }
        if (c) {
            dot3.setBackgroundResource(R.drawable.dot_select);
        } else {
            dot3.setBackgroundResource(R.drawable.dot_notselect);
        }
    }

    // 初始化
    private void init() {
        tcpsocket = new TcpSocket();
        edit_num1 = findViewById(R.id.edit_num1);
        edit_num2 = findViewById(R.id.edit_num2);
        edit_num3 = findViewById(R.id.edit_num3);
        edit_num4 = findViewById(R.id.edit_num4);

        EditListener ed1 = new EditListener(edit_num1);
        EditListener ed2 = new EditListener(edit_num2);
        EditListener ed3 = new EditListener(edit_num3);
        EditListener ed4 = new EditListener(edit_num4);
        edit_num1.addTextChangedListener(ed1);
        edit_num2.addTextChangedListener(ed2);
        edit_num3.addTextChangedListener(ed3);
        edit_num4.addTextChangedListener(ed4);
        edit_msg = findViewById(R.id.edit_msg);
        bt_send = findViewById(R.id.bt_send);

        BtListener l = new BtListener();
        bt_send.setOnClickListener(l);
    }

    // 按钮监听
    private class BtListener implements View.OnClickListener {
        @Override
        public void onClick(View v) {
            //广告内容发送
            if (v == bt_send) {
                String msg = edit_msg.getText().toString();
                MainActivity.tcpsocket.sendDataToServer("LED_" + msg);
            }
        }
    }

    // 数码管编辑框监听
    private class EditListener implements TextWatcher {
        private EditText e_view;

        public EditListener(EditText e_view) {
            this.e_view = e_view;
        }

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            // 检测填入的数字是否大于2个，如果是只保留一个、
            Log.d("MSG", s.toString() + "||" + start + "||" + before + "||" + count);
            String msg = "";
            if (s.toString().length() >= 2) {
                String edit = e_view.getText().toString();
                msg = edit.substring(0, 1);
                e_view.setText(msg);
            }
            // 发送
            String e1 = "0";
            String e2 = "0";
            String e3 = "0";
            String e4 = "0";
            String edit1 = edit_num1.getText().toString();
            String edit2 = edit_num2.getText().toString();
            String edit3 = edit_num3.getText().toString();
            String edit4 = edit_num4.getText().toString();
            if (!edit1.equals("")) {
                e1 = edit1;
            }
            if (!edit2.equals("")) {
                e2 = edit2;
            }
            if (!edit3.equals("")) {
                e3 = edit3;
            }
            if (!edit4.equals("")) {
                e4 = edit4;
            }
            tcpsocket.sendDataToServer("DIG_" + e1 + "_" + e2 + "_" + e3 + "_" + e4);
        }

        @Override
        public void afterTextChanged(Editable s) {
        }
    }
}



