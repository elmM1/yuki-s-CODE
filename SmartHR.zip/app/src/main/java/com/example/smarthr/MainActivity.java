package com.example.smarthr;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.example.smarthr.bean.SecurityBean;
import com.example.smarthr.bean.SensorBean;
import com.example.smarthr.tool.IntentSkip;
import com.example.smarthr.tool.TcpSocket;
import com.google.gson.Gson;


import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    //当前类对象
    public static  AppCompatActivity ac;
    //Tcp网络对象
    public static TcpSocket tcpsocket;
    //组件
    private ImageView bt_wifi, img_state;
    private Button bt_ex1,bt_ex2,bt_ex3,bt_ex4;
    //实体类
    public static SecurityBean securityBean;
    public static SensorBean sensorBean;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // 获取应用程序中的bn按钮
        Button bt_ex1 =findViewById(R.id.bt_ex1);
        Button bt_ex2 =findViewById(R.id.bt_ex2);
        Button bt_ex3 =findViewById(R.id.bt_ex3);
        Button bt_ex4 =findViewById(R.id.bt_ex4);
        // 为bn按钮绑定事件监听器
        bt_ex1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(MainActivity.this, Ex1Activity.class);
                // 启动intent对应的Activity
                startActivity(intent);
            }
        });
        bt_ex2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View source) {
                // 获取启动当前Activity的上一个Intent
                Intent intent = new Intent(MainActivity.this, Ex2Activity.class);
                // 启动intent对应的Activity
                startActivity(intent);
            }
        });
        bt_ex3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View source) {
                // 获取启动当前Activity的上一个Intent
                Intent intent = new Intent(MainActivity.this, Ex3Activity.class);
                // 启动intent对应的Activity
                startActivity(intent);
            }
        });
        bt_ex4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View source) {
                // 获取启动当前Activity的上一个Intent
                Intent intent = new Intent(MainActivity.this, Ex4Activity.class);
                // 启动intent对应的Activity
                startActivity(intent);
            }
        });
        getSupportActionBar().hide();
        init();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }



    private void init() {
        ac = this;
        tcpsocket = new TcpSocket();
        tcpsocket.setListener(new TcpListener());
        bt_wifi = findViewById(R.id.bt_wifi);
        img_state = findViewById(R.id.img_state);
        bt_ex1 = findViewById(R.id.bt_ex1);
        bt_ex2 = findViewById(R.id.bt_ex2);
        bt_ex3 = findViewById(R.id.bt_ex3);
        bt_ex4 = findViewById(R.id.bt_ex4);
        //监听函数
        BtListener l = new BtListener();

        bt_wifi.setOnClickListener(l);
    }

    // 显示连接对话框
    private void showTcpDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(ac);
        View dialogView = LayoutInflater.from(ac).inflate(R.layout.edit_tcp, null);
        builder.setTitle("网络连接");
        builder.setView(dialogView);
        builder.setNegativeButton("取消", null);
        builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                EditText edit_ip = dialogView.findViewById(R.id.edit_ip);
                EditText edit_port = dialogView.findViewById(R.id.edit_port);
                String ip = edit_ip.getText().toString();
                int port = Integer.parseInt(edit_port.getText().toString());
                // 连接
                tcpsocket.conncet(ip, port);
            }
        });
        builder.show();
    }

    // 网络监听
    private class TcpListener implements TcpSocket.OnReadListener {
        @Override
        public void onConneting() {}

        @Override
        public void onConnectSuccess(String ip) {
            Toast.makeText(ac, ip + "连接成功", Toast.LENGTH_SHORT).show();
            img_state.setImageResource(R.mipmap.img_yes);
        }

        @Override
        public void onConnectTimeOut() {
            Toast.makeText(ac, "连接失败，请检查IP端口", Toast.LENGTH_SHORT).show();
            img_state.setImageResource(R.mipmap.img_no);
        }

        @Override
        public void onConnectLost() {
            Toast.makeText(ac, "连接断开了", Toast.LENGTH_SHORT).show();
            img_state.setImageResource(R.mipmap.img_no);
        }

        @Override
        public void onRead(byte[] b, int len, Socket so) {
            String msg = new String(b, 0, len);
            Gson gson=new Gson();
            try {
                String[] split = msg.split("_");
                // 安防协议
                if (split[0].equals("SECURITY")){
                     securityBean=gson.fromJson(split[1],SecurityBean.class);
                }
                // 传感器协议
                if(split[0].equals("SENSOR")){
                     sensorBean=gson.fromJson(split[1],SensorBean.class);
                }
            }catch (Exception e){
                Log.e("MSG","解析错误："+e.getMessage());
            }
        }
    }

    private class BtListener implements View.OnClickListener {
        @Override
        public void onClick(View v) {
            if (v == bt_wifi) {
                // 打开网络连接窗口
                showTcpDialog();
            }
            if(!tcpsocket.isConnect){
                Toast.makeText(ac,"请点击右上角先连接",Toast.LENGTH_SHORT).show();
                return;
            }
            if (v == bt_ex1){
                IntentSkip.toAcvitity(ac,Ex1Activity.class);
                return;
            }
            if (v == bt_ex2){
                IntentSkip.toAcvitity(ac,Ex2Activity.class);
                return;
            }
            if (v == bt_ex3){
                IntentSkip.toAcvitity(ac,Ex3Activity.class);
                return;
            }
            if (v == bt_ex4){
                IntentSkip.toAcvitity(ac,Ex4Activity.class);
                return;
            }
        }
    }
}

