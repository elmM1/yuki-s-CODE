package com.example.smarthr;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.smarthr.bean.SensorBean;
import com.example.smarthr.tool.TcpSocket;
import com.google.gson.Gson;

import java.io.Serializable;
import java.net.Socket;

public class Ex2Activity extends AppCompatActivity {
    private boolean isRun = true;
    private TextView text_temp,text_hum,text_light,text_air,text_pressure;

    @Override
    protected void onCreate( Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ex2);
        getSupportActionBar().hide();
        //组件
        text_temp = findViewById(R.id.text_temp);
        text_hum = findViewById(R.id.text_hum);
        text_light = findViewById(R.id.text_light);
        text_air = findViewById(R.id.text_air);
        text_pressure = findViewById(R.id.text_pressure);

        //启动获取数据线程
        new Thread(new TimeThread()).start();
    }

    private class TimeThread implements Runnable{
        @Override
        public void run() {
            while(isRun){
                if(MainActivity.sensorBean == null){
                    //休眠1s
                    try {
                        Thread.sleep(1000);
                    }catch (InterruptedException e){
                        e.printStackTrace();
                        throw new RuntimeException();
                    }
                    continue;
                }runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        //组件
                        text_temp.setText(MainActivity.sensorBean.TEMP + "℃");
                        text_hum.setText(MainActivity.sensorBean.HUM + "%");
                        text_light.setText(MainActivity.sensorBean.LIGHT + "");
                        text_air.setText(MainActivity.sensorBean.AIR + "");
                        text_pressure.setText(MainActivity.sensorBean.PR + "");
                    }
                });
                try{
                    Thread.sleep(1000);
                }catch (InterruptedException e){
                    e.printStackTrace();
                }
            }
        }
    }
}
